"""Domain-agnostic contract models."""
